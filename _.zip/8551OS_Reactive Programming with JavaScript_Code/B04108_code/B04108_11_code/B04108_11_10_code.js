      getInitialState: function() {
        return {
          'items': [],
          'text': ''
        };
      },
