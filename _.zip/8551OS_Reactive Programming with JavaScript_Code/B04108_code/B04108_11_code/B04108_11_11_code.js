      getInitialState: function() {
        return restore('Todo', {
          'items': [],
          'text': ''
        });
      },
