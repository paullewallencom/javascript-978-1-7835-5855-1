      this.state.entries.push(this.state.entry_being_added);
      this.state.entry_being_added = this.new_entry();
