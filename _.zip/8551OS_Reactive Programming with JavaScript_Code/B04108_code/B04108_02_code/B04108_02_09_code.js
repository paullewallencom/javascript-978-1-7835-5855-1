console.log('Before: ' + before);
console.log('Same: ' + same);
console.log('After: ' + after);
