var counter = 0;
for(var field in obj) {
  counter += 1;
}
