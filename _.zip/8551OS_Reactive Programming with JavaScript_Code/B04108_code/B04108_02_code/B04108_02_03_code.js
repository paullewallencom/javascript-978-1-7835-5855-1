/*
 * Multiline comments are legal.
 */

if (x) // In this case, we ...
