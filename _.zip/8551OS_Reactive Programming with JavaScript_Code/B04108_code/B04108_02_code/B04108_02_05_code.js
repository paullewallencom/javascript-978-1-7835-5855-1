var add = function(first, second) {
  return first + second;
}

console.log(add(1, 2));
