var sample = {
  'a': 12,
  'b': 2.5
};
