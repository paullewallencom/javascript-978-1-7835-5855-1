var x;
var y = 12 + 2;
