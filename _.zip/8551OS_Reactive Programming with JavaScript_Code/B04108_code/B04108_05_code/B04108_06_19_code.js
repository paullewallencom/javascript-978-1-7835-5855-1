Math.pow(2, Math.pow(3, 4))
Math.pow(Math.pow(2, 3), 4)
