words.sort(case_insensitive_comparison);
