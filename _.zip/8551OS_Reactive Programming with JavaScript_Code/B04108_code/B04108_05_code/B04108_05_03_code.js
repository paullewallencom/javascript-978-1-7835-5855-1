var fruits = ['apple', 'durian', 'banana', 'canteloupe'];
