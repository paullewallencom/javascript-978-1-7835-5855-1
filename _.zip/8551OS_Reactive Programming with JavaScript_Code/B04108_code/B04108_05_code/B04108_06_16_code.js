var factorial = one_to_ten.reduce(function(x, y) {return x * y});
