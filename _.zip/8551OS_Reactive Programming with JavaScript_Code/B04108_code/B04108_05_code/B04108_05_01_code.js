var digits = [3, 1, 4, 1, 5, 9];
digits.sort();
console.log(digits);
