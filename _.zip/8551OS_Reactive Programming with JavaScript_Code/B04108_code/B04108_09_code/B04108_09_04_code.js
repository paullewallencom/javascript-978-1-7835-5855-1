      onChange: function(event) {
        this.setState({text: event.target.value});
      },
