      render: function() {
        var that = this;
        var table_rows = [];
