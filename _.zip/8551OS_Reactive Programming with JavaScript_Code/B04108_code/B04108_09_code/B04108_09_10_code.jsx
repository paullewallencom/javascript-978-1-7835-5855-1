        table_rows.push(
          <tr>{this.state.items.map(display_item)}</tr>);
