var Todo = React.createClass({
    mixins: [React.addons.LinkedStateMixin],
