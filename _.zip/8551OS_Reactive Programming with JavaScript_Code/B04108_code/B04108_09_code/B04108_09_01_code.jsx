  var Pragmatometer = React.createClass(
    {
    render: function()
      {
      return (
        <div className="Pragmatometer">
          <Calendar />
          <Todo />
          <Scratch />
          {/* <YouPick /> */}
        </div>
        );
      }
    });
