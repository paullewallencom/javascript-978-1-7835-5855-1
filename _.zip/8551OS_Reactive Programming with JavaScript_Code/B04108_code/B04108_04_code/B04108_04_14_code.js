    getDefaultProps: function() {
      return null;
    },
    getInitialState: function() {
      return board;
    },
