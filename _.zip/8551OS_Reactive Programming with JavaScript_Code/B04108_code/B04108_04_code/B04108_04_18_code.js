        React.render(
          React.createElement(DisplayGrid, {}),
          document.getElementById('display'));
