  else {
    rows = get_level();
    score += level * level;
    position = 0;
    row = 1;
  }
}
