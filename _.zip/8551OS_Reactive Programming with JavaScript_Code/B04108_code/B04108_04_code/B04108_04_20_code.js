    var shot_taken = false;
