  var start_game = function() {
    game_over = false;
    level = 1;
    position = 0;
    row = 1;
    score = 0;
    chance_clear = 5 / 6;
  }
  start_game();
