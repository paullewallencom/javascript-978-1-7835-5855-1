    var tick = function() {
      if (game_over) {
        return;
      }
