    board.rows[row][position - 1] = ' ';
