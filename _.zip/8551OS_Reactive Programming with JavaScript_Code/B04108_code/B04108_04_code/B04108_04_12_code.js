  var board = {'rows': get_level()};
  var keystrokes = [];
