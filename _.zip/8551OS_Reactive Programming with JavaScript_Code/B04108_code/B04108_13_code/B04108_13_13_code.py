python -c "import binascii; print binascii.hexlify(open('/dev/random').read(1024))"
