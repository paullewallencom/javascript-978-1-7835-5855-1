      result.push(<li><input type="checkbox" name="all_day"
        id="all_day" />All day event.
        &nbsp;<strong>&mdash;or&mdash;</strong>&nbsp;
        <select id="hours" id="hours"
        defaultValue="12">{hours}</select>:
      <select id="minutes" id="minutes"
        defaultValue="0">{minutes}</select></li>);
