    getInitialState: function() {
      return {entries: [], entry_being_added: this.new_entry()};
      },
