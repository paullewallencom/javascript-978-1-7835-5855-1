    render_upcoming: function() {
      var that = this;
      var result = [];
