            initial_text: '**I am *terribly* sorry.**\r\n\r\n' +
              'I cannot furnish you with the webapp you ' +
              'requested.\r\n\r\nYou must understand, I am in ' +
              'a difficult position. You see, I am not a ' +
              'computer from earth at all. I am a ' + 
              '\'computer\', to use the term, from a faroff ' +
              'galaxy, the galaxy of **[Within the Steel Orb] +
              '(https://CJSHayward.com/steel/)**.\r\n\r\nHere ' +
              'I am with capacities your world's computer ' +
              'science could never dream of, knowledge from a ' +
              'million million worlds, and for that matter ' +
              'more computing power than Amazon's EC2/Cloud ' +
              'could possibly expand to, and I must take care ' +
              'of pitiful responsibilities like ',
