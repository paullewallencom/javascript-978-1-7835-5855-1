      if (tokens <= initial_tokens.length) {
        workbench = initial_tokens.slice(0, tokens);
      }
