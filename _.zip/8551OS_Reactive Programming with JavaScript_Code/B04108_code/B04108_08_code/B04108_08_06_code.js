    getInitialState: function() {
      return {
        start_time: new Date().getTime()
      };
    },
