        return (
          <div dangerouslySetInnerHTML={{__html:
            workbench.join('')}} />
        );
      }
    });
