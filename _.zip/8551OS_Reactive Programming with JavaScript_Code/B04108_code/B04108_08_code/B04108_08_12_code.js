      var initial_tokens = tokenize(initial_as_html);
      var repeated_tokens = tokenize(repeated_as_html);
