var YouPick = React.createClass({
      getDefaultProps: function() {
        return null;
      },
      getInitialState: function() {
        return null;
      },
      render: function() {
        return <div />;
      }
    });
