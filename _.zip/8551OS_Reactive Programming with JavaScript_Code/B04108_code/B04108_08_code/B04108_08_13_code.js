      var tokens = Math.floor((new Date().getTime() -
        that.state.start_time) / that.props.interval);
