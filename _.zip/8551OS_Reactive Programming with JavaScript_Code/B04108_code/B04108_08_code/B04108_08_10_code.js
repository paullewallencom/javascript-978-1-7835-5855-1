      var initial_as_html = converter.makeHtml(
        that.props.initial_text);
      var repeated_as_html = converter.makeHtml(
        that.props.repeated_text);
