getDefaultProps: function() {
          return {
            initial_text: '<p><strong>I am <em>terribly</em> ' + 
              'sorry.</strong></p><p>I cannot provide you with ' +
              'the webapp you requested.</p><p>You must ' + 
              'understand, I am in a difficult position. You ' + 
              'see, I am not a computer from earth at all. I ' +
              'am a \'computer\', to use the term, from a ' +
              'faroff galaxy: the galaxy of <strong><a ' +
              'href="https://CJSHayward.com/steel/">Within ' +
              'the Steel Orb</a></strong>.</p><p>Here I am ' +
              'with capacities your world's computer science ' + 
              'could never dream of, knowledge from a million, ' +
              'million worlds, and for that matter more ' +
              'computing power than Amazon's EC2/Cloud could ' +
              'possibly expand to, and I must take care of ' +
              'pitiful responsibilities like ',
            interval: 100,
            repeated_text: 'helping you learn web development '
          };
        },
