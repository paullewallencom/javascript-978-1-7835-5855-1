var Calendar = React.createClass({
      render: function() {
        return <div />;
      }
    });
    var Scratchpad = React.createClass({
      render: function() {
        return <div />;
      }
    });
    var Todo = React.createClass({
      render: function() {
        return <div />;
      }
    });
